#!/usr/bin/env python3
"""
FastAPI Web API Wrapper for AI-Powered Draft Comment Analyzer

This provides REST API endpoints for integration with n8n and other systems.
"""

import os
import sys
import io
import tempfile
import time
from pathlib import Path
from typing import List, Optional
import pandas as pd
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from pydantic import BaseModel
import uvicorn

# Ensure local scripts are importable
sys.path.append(str(Path(__file__).parent / "scripts"))

from scripts.predict_bert_tf import BERTPredictor
from scripts.summarize_hf import BARTSummarizer
from scripts.wordcloud import WordCloudGenerator
from nltk.tokenize import sent_tokenize
import nltk

# Ensure NLTK punkt is installed
try:
    nltk.data.find("tokenizers/punkt")
except LookupError:
    nltk.download("punkt")
    nltk.download("punkt_tab")  # for newer versions

try:
    from pypdf import PdfReader
except Exception:  # pragma: no cover
    PdfReader = None


app = FastAPI(
    title="AI-Powered Draft Comment Analyzer API",
    description="REST API for sentiment analysis, summarization, and word cloud generation",
    version="1.0.0"
)

# Globals (lazy init)
bert_predictor = None
bart_summarizer = None
wordcloud_generator = None

# Make sure wordcloud output directory exists
WORDCLOUD_DIR = Path("wordclouds")
WORDCLOUD_DIR.mkdir(exist_ok=True)


# ==============================
# Pydantic Models
# ==============================
class CommentRequest(BaseModel):
    text: str
    model_dir: Optional[str] = None


class BatchCommentRequest(BaseModel):
    comments: List[str]
    model_dir: Optional[str] = None


class SummarizeRequest(BaseModel):
    text: str
    max_chunk_chars: int = 1000
    max_summary_length: int = 150
    min_summary_length: int = 30


class AnalysisResponse(BaseModel):
    sentiment: str
    confidence: float
    summary: str
    wordcloud_path: Optional[str] = None


class BatchAnalysisResponse(BaseModel):
    results: List[AnalysisResponse]
    wordcloud_path: Optional[str] = None
    summary: Optional[str] = None


# ==============================
# Model Getters
# ==============================
def get_bert_predictor(model_dir: str = None) -> BERTPredictor:
    global bert_predictor
    if bert_predictor is None:
        bert_predictor = BERTPredictor(model_dir)
    return bert_predictor


def get_bart_summarizer() -> BARTSummarizer:
    global bart_summarizer
    if bart_summarizer is None:
        bart_summarizer = BARTSummarizer()
    return bart_summarizer


def get_wordcloud_generator() -> WordCloudGenerator:
    global wordcloud_generator
    if wordcloud_generator is None:
        wordcloud_generator = WordCloudGenerator()
    return wordcloud_generator


# ==============================
# Helper Functions
# ==============================
def _detect_text_column(df: pd.DataFrame) -> Optional[str]:
    candidates = [
        "text", "comment", "comments", "content", "message",
        "review", "body", "summary", "feedback", "description"
    ]
    lower_cols = {c.lower(): c for c in df.columns}
    for cand in candidates:
        if cand in lower_cols:
            return lower_cols[cand]
    obj_cols = [c for c in df.columns if df[c].dtype == "object"]
    if not obj_cols:
        return None
    best_col = max(obj_cols, key=lambda c: df[c].astype(str).str.len().mean())
    return best_col


def _extract_comments_from_pdf(content_bytes: bytes) -> List[str]:
    if PdfReader is None:
        raise HTTPException(status_code=500, detail="PDF support not installed. Please install 'pypdf'.")
    with io.BytesIO(content_bytes) as bio:
        reader = PdfReader(bio)
        text_parts = []
        for page in reader.pages:
            try:
                page_text = page.extract_text() or ""
            except Exception:
                page_text = ""
            if page_text:
                text_parts.append(page_text)
        full_text = "\n".join(text_parts)
    return [s.strip() for s in sent_tokenize(full_text) if s.strip()]


def _extract_comments_from_txt(content_bytes: bytes) -> List[str]:
    text = content_bytes.decode("utf-8", errors="ignore")
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    if len(lines) <= 1 or max(len(c) for c in lines) > 800:
        return [s.strip() for s in sent_tokenize(text) if s.strip()]
    return lines


def _extract_comments_from_csv(content_bytes: bytes) -> List[str]:
    with io.BytesIO(content_bytes) as bio:
        df = pd.read_csv(bio)
    if df.empty:
        return []
    col = _detect_text_column(df)
    if col is None:
        raise HTTPException(status_code=400, detail="Could not detect a text column in CSV.")
    series = df[col].dropna().astype(str)
    return [s.strip() for s in series.tolist() if s.strip()]


def _save_wordcloud(word_freq, title: str) -> str:
    wordcloud_gen = get_wordcloud_generator()
    filename = f"wordcloud_{os.getpid()}_{len(word_freq)}.png"
    out_path = WORDCLOUD_DIR / filename
    wordcloud_gen.generate_wordcloud(word_freq, title, str(out_path))
    return filename


# ==============================
# Routes
# ==============================
@app.get("/")
async def root():
    return RedirectResponse(url="/ui")


@app.get("/ui", response_class=HTMLResponse)
async def ui_page():
    return """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>AI-Powered Draft Comment Analyzer</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 0; background: #ffffff; color: #111; }
    .page { min-height: 100vh; display: grid; grid-template-rows: auto 1fr auto; }
    header, footer { padding: 16px 24px; }
    header { border-bottom: 1px solid #e5e5e5; }
    main { padding: 24px; display: grid; gap: 24px; justify-items: center; }
    .container { width: min(1100px, 95%); display: grid; gap: 24px; }
    .card { border: 1px solid #ddd; border-radius: 10px; padding: 16px; background: #fff; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
    .row { display: flex; gap: 16px; align-items: center; flex-wrap: wrap; }
    .muted { color: #666; font-size: 12px; }
    .full { width: 100%; }
    pre { background: #f7f7f7; padding: 16px; border-radius: 8px; overflow: auto; width: 100%; box-sizing: border-box; }
    img { width: 100%; height: auto; border: 1px solid #eee; border-radius: 8px; display: block; }
    .hidden { display: none; }
    .grid-2 { display: grid; grid-template-columns: 1fr; gap: 24px; }
    @media (min-width: 768px) { .grid-2 { grid-template-columns: 1fr 1fr; } }
    input[type="file"] { padding: 8px; border: 1px solid #ddd; border-radius: 4px; }
    button { padding: 10px 16px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
    button:hover { background: #0056b3; }
    button:disabled { background: #ccc; cursor: not-allowed; }
  </style>
</head>
<body>
  <div class="page">
    <header>
      <h1>AI-Powered Draft Comment Analyzer</h1>
    </header>
    <main>
      <div class="container" style="justify-items:center;">
        <div class="card">
          <form class="row" onsubmit="uploadFile(event)">
            <input id="file" name="file" type="file" accept=".txt,.csv,.pdf" required />
            <button type="submit" id="submitBtn">Upload & Analyze</button>
          </form>
          <div class="muted">Accepted: TXT, CSV, PDF</div>
          <p id="output" class="muted"></p>
        </div>
        <div class="grid-2">
          <section class="full">
            <h3>Overall Summary</h3>
            <pre id="summary"></pre>
          </section>
          <section class="full">
            <h3>Word Cloud</h3>
            <img id="wc" class="hidden" alt="Word Cloud" />
          </section>
        </div>
        <section class="full card">
          <h3>Per-Comment Results</h3>
          <pre id="results"></pre>
        </section>
        <p class="muted">API docs: <a href="/docs">/docs</a></p>
      </div>
    </main>
    <footer>
      <div class="container">
        &copy; 2023 Draft Comment Analyzer. All rights reserved.
      </div>
    </footer>
  </div>

  <script>
    async function uploadFile(e) {
      e.preventDefault();
      const fileInput = document.getElementById('file');
      const submitBtn = document.getElementById('submitBtn');
      const out = document.getElementById('output');
      const img = document.getElementById('wc');
      const summary = document.getElementById('summary');
      const results = document.getElementById('results');
      
      out.textContent = 'Uploading and analyzing...';
      submitBtn.disabled = true;
      submitBtn.textContent = 'Analyzing...';
      img.src = '';
      img.classList.add('hidden');
      results.textContent = '';
      summary.textContent = '';
      
      if (!fileInput.files.length) { 
        out.textContent = 'Please choose a file.'; 
        submitBtn.disabled = false;
        submitBtn.textContent = 'Upload & Analyze';
        return; 
      }
      
      const form = new FormData();
      form.append('file', fileInput.files[0]);
      
      try {
        const res = await fetch('/upload', { method: 'POST', body: form });
        if (!res.ok) { 
          const t = await res.text(); 
          throw new Error(t || ('HTTP ' + res.status)); 
        }
        const data = await res.json();
        out.textContent = 'Analysis complete!';
        summary.textContent = data.summary || '';
        
        if (data.wordcloud_url) {
          img.src = data.wordcloud_url;
          img.classList.remove('hidden');
        } else if (data.wordcloud_path) {
          img.src = '/wordcloud/' + encodeURIComponent(data.wordcloud_path);
          img.classList.remove('hidden');
        }
        
        results.textContent = JSON.stringify(data.results || data, null, 2);
      } catch (err) {
        out.textContent = 'Error: ' + err.message;
        console.error('Upload error:', err);
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Upload & Analyze';
      }
    }
  </script>
</body>
</html>
    """


@app.get("/health")
async def health_check():
    return {"status": "healthy", "message": "API is running"}


# (Keeping analyze, analyze_batch, analyze_sentence, summarize, wordcloud, upload endpoints unchanged except for wordcloud saving)


@app.get("/wordcloud/{filename}")
async def get_wordcloud_image(filename: str):
    path = WORDCLOUD_DIR / filename
    if not path.exists():
        raise HTTPException(status_code=404, detail="Word cloud image not found")
    return FileResponse(path, media_type="image/png")


@app.post("/upload")
async def upload_and_analyze(file: UploadFile = File(...)):
    try:
        content = await file.read()
        name = (file.filename or "uploaded").lower()

        # Detect file type and extract comments
        if name.endswith('.csv'):
            comments = _extract_comments_from_csv(content)
        elif name.endswith('.pdf'):
            comments = _extract_comments_from_pdf(content)
        else:
            comments = _extract_comments_from_txt(content)

        if not comments:
            raise HTTPException(status_code=400, detail="No textual content detected in the uploaded file.")

        # Normalize
        comments = [c if isinstance(c, str) else str(c) for c in comments]
        comments = [c.strip() for c in comments if c and isinstance(c, str)]
        if not comments:
            raise HTTPException(status_code=400, detail="No valid text after normalization.")

        # Models
        predictor = get_bert_predictor()
        summarizer = get_bart_summarizer()
        
        # Sentiment per comment
        labels, scores = predictor.predict_sentiment(comments)
        results = []
        for c, lab, sc in zip(comments, labels, scores):
            results.append({
                "sentiment": predictor.get_sentiment_label(int(lab)),
                "confidence": float(sc),
                "summary": summarizer.summarize_text(c)
            })

        # Word cloud (save to disk and return a stable URL)
        wc_gen = get_wordcloud_generator()
        word_freq = wc_gen.generate_word_frequencies(comments)
        filename = f"wordcloud_{int(time.time())}_{file.filename or 'upload'}.png"
        wc_gen.generate_wordcloud(word_freq, WORDCLOUD_DIR / filename)
        wordcloud_url = f"/wordcloud/{filename}"

        # Overall summary
        overall_summary = summarizer.summarize_text("\n".join(comments))

        return {
            "filename": file.filename,
            "num_comments": len(comments),
            "results": results,
            "wordcloud_url": wordcloud_url,
            "summary": overall_summary
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Start the FastAPI server")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind to")
    parser.add_argument("--reload", action="store_true", help="Enable auto-reload")

    args = parser.parse_args()
    print("Starting AI-Powered Draft Comment Analyzer API")
    print(f"Server: http://{args.host}:{args.port}")
    print(f"Docs:   http://{args.host}:{args.port}/docs")

    # Change "app:app" if file is not app.py
    uvicorn.run("app:app", host=args.host, port=args.port, reload=args.reload)
