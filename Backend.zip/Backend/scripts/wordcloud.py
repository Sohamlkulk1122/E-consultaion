#!/usr/bin/env python3
"""
Word Cloud Generation Script

This script generates word clouds from text data with optional sentiment-based filtering.
"""

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Set, Optional
import pandas as pd
import matplotlib.pyplot as plt
from wordcloud import WordCloud
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from collections import Counter
import re
import warnings
warnings.filterwarnings('ignore')


# Download required NLTK data
try:
    nltk.data.find('corpora/stopwords')
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('stopwords')
    nltk.download('punkt')


class WordCloudGenerator:
    """Word cloud generator with sentiment filtering support."""
    
    def __init__(self, 
                 extra_stopwords: Optional[List[str]] = None,
                 max_words: int = 100,
                 width: int = 800,
                 height: int = 400):
        """
        Initialize word cloud generator.
        
        Args:
            extra_stopwords: Additional stopwords to exclude
            max_words: Maximum number of words in word cloud
            width: Width of word cloud image
            height: Height of word cloud image
        """
        self.max_words = max_words
        self.width = width
        self.height = height
        
        # Get default stopwords
        self.stopwords = set(stopwords.words('english'))
        
        # Add extra stopwords
        if extra_stopwords:
            self.stopwords.update(extra_stopwords)
        
        # Add common consultation/policy terms that might not be informative
        consultation_stopwords = {
            'proposal', 'amendment', 'policy', 'bill', 'legislation', 'act',
            'section', 'subsection', 'clause', 'paragraph', 'article',
            'government', 'ministry', 'department', 'agency', 'commission',
            'committee', 'council', 'board', 'panel', 'group', 'team',
            'document', 'report', 'study', 'analysis', 'review', 'assessment',
            'implementation', 'development', 'establishment', 'creation',
            'consideration', 'discussion', 'consultation', 'feedback',
            'stakeholder', 'participant', 'respondent', 'contributor',
            'process', 'procedure', 'method', 'approach', 'strategy',
            'framework', 'guideline', 'standard', 'criteria', 'requirement'
        }
        
        self.stopwords.update(consultation_stopwords)
    
    def preprocess_text(self, text: str) -> str:
        """
        Preprocess text for word cloud generation.
        
        Args:
            text: Input text
        
        Returns:
            Preprocessed text
        """
        if not text or pd.isna(text):
            return ""
        
        # Convert to lowercase
        text = text.lower()
        
        # Remove special characters and numbers
        text = re.sub(r'[^a-zA-Z\s]', '', text)
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    def extract_words(self, text: str) -> List[str]:
        """
        Extract meaningful words from text.
        
        Args:
            text: Input text
        
        Returns:
            List of words
        """
        preprocessed = self.preprocess_text(text)
        
        if not preprocessed:
            return []
        
        # Tokenize
        words = word_tokenize(preprocessed)
        
        # Filter out stopwords and short words
        filtered_words = [
            word for word in words 
            if word not in self.stopwords and len(word) > 2
        ]
        
        return filtered_words
    
    def generate_word_frequencies(self, texts: List[str]) -> Dict[str, int]:
        """
        Generate word frequencies from a list of texts.
        
        Args:
            texts: List of input texts
        
        Returns:
            Dictionary of word frequencies
        """
        all_words = []
        
        for text in texts:
            words = self.extract_words(str(text))
            all_words.extend(words)
        
        # Count word frequencies
        word_freq = Counter(all_words)
        
        # Return top words
        return dict(word_freq.most_common(self.max_words))
    
    def generate_wordcloud(self, 
                          word_freq: Dict[str, int],
                          title: str = "Word Cloud",
                          output_path: str = "wordcloud.png") -> None:
        """
        Generate and save word cloud image.
        
        Args:
            word_freq: Dictionary of word frequencies
            title: Title for the word cloud
            output_path: Path to save the image
        """
        if not word_freq:
            print(f"No words found for {title}")
            return
        
        # Create word cloud
        wordcloud = WordCloud(
            width=self.width,
            height=self.height,
            background_color='white',
            max_words=self.max_words,
            colormap='viridis',
            relative_scaling=0.5,
            random_state=42
        ).generate_from_frequencies(word_freq)
        
        # Create figure
        plt.figure(figsize=(12, 6))
        plt.imshow(wordcloud, interpolation='bilinear')
        plt.axis('off')
        plt.title(title, fontsize=16, fontweight='bold')
        plt.tight_layout()
        
        # Save image
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"Word cloud saved to {output_path}")
    
    def generate_sentiment_wordclouds(self, 
                                    df: pd.DataFrame,
                                    output_dir: str = ".") -> None:
        """
        Generate separate word clouds for different sentiments.
        
        Args:
            df: DataFrame with text and sentiment columns
            output_dir: Directory to save word clouds
        """
        sentiments = df['sentiment'].unique()
        
        for sentiment in sentiments:
            if pd.isna(sentiment):
                continue
            
            # Filter texts by sentiment
            sentiment_texts = df[df['sentiment'] == sentiment]['text'].tolist()
            
            if not sentiment_texts:
                continue
            
            # Generate word frequencies
            word_freq = self.generate_word_frequencies(sentiment_texts)
            
            # Generate word cloud
            title = f"Word Cloud - {sentiment.title()} Sentiment"
            output_path = os.path.join(output_dir, f"wordcloud_{sentiment.lower()}.png")
            
            self.generate_wordcloud(word_freq, title, output_path)


def load_extra_stopwords(file_path: str) -> List[str]:
    """
    Load additional stopwords from file.
    
    Args:
        file_path: Path to stopwords file
    
    Returns:
        List of additional stopwords
    """
    if not os.path.exists(file_path):
        return []
    
    with open(file_path, 'r', encoding='utf-8') as f:
        stopwords = [line.strip() for line in f if line.strip()]
    
    return stopwords


def process_comments_wordcloud(input_csv: str,
                             generator: WordCloudGenerator,
                             by_sentiment: bool = False) -> None:
    """
    Process comments and generate word clouds.
    
    Args:
        input_csv: Path to input CSV file
        generator: Word cloud generator instance
        by_sentiment: Whether to generate sentiment-specific word clouds
    """
    print(f"Loading comments from {input_csv}")
    df = pd.read_csv(input_csv)
    
    if df.empty:
        print("No data found in input file")
        return
    
    # Generate main word cloud
    all_texts = df['text'].tolist()
    word_freq = generator.generate_word_frequencies(all_texts)
    generator.generate_wordcloud(word_freq, "Word Cloud - All Comments", "wordcloud.png")
    
    # Generate sentiment-specific word clouds if requested
    if by_sentiment and 'sentiment' in df.columns:
        print("Generating sentiment-specific word clouds")
        generator.generate_sentiment_wordclouds(df)
    
    # Print top words
    print(f"\nTop 20 words:")
    for word, freq in list(word_freq.items())[:20]:
        print(f"  {word}: {freq}")


def process_sentence_level_wordcloud(input_csv: str,
                                   generator: WordCloudGenerator,
                                   by_sentiment: bool = False) -> None:
    """
    Process sentence-level results and generate word clouds.
    
    Args:
        input_csv: Path to input CSV file with sentence-level results
        generator: Word cloud generator instance
        by_sentiment: Whether to generate sentiment-specific word clouds
    """
    print(f"Loading sentence-level results from {input_csv}")
    df = pd.read_csv(input_csv)
    
    if df.empty:
        print("No data found in input file")
        return
    
    # Use sentence_text column if available, otherwise use text column
    text_column = 'sentence_text' if 'sentence_text' in df.columns else 'text'
    
    # Generate main word cloud
    all_texts = df[text_column].tolist()
    word_freq = generator.generate_word_frequencies(all_texts)
    generator.generate_wordcloud(word_freq, "Word Cloud - All Sentences", "wordcloud.png")
    
    # Generate sentiment-specific word clouds if requested
    if by_sentiment and 'sentiment' in df.columns:
        print("Generating sentiment-specific word clouds")
        generator.generate_sentiment_wordclouds(df)
    
    # Print top words
    print(f"\nTop 20 words:")
    for word, freq in list(word_freq.items())[:20]:
        print(f"  {word}: {freq}")


def main():
    """Main word cloud generation script."""
    parser = argparse.ArgumentParser(description="Generate word clouds from text data")
    
    parser.add_argument(
        "--input",
        type=str,
        required=True,
        help="Input CSV file path"
    )
    
    parser.add_argument(
        "--output",
        type=str,
        default="wordcloud.png",
        help="Output word cloud image path"
    )
    
    parser.add_argument(
        "--extra-stop",
        type=str,
        help="Path to file with additional stopwords"
    )
    
    parser.add_argument(
        "--by-sentiment",
        action="store_true",
        help="Generate separate word clouds by sentiment"
    )
    
    parser.add_argument(
        "--max-words",
        type=int,
        default=100,
        help="Maximum number of words in word cloud"
    )
    
    parser.add_argument(
        "--width",
        type=int,
        default=800,
        help="Width of word cloud image"
    )
    
    parser.add_argument(
        "--height",
        type=int,
        default=400,
        help="Height of word cloud image"
    )
    
    parser.add_argument(
        "--sentence-level",
        action="store_true",
        help="Process sentence-level results (draft mode)"
    )
    
    args = parser.parse_args()
    
    try:
        # Load extra stopwords if provided
        extra_stopwords = []
        if args.extra_stop:
            extra_stopwords = load_extra_stopwords(args.extra_stop)
            print(f"Loaded {len(extra_stopwords)} additional stopwords")
        
        # Initialize word cloud generator
        generator = WordCloudGenerator(
            extra_stopwords=extra_stopwords,
            max_words=args.max_words,
            width=args.width,
            height=args.height
        )
        
        if args.sentence_level:
            # Process sentence-level results
            process_sentence_level_wordcloud(
                args.input, generator, args.by_sentiment
            )
        else:
            # Process comment-level results
            process_comments_wordcloud(
                args.input, generator, args.by_sentiment
            )
        
        print(f"\nWord cloud generation completed successfully!")
        
    except Exception as e:
        print(f"Error during word cloud generation: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
