#!/usr/bin/env python3
"""
BERT Training Script for Sentiment Analysis

This script fine-tunes a BERT model from TensorFlow Hub on custom labeled data
for sentiment analysis tasks.
"""

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Tuple
import pandas as pd
import numpy as np
import tensorflow as tf
import tensorflow_hub as hub
import tensorflow_text as text
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix
import matplotlib.pyplot as plt
import seaborn as sns


# TensorFlow Hub BERT model URLs
BERT_PREPROCESSOR_URL = "https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3"
BERT_ENCODER_URL = "https://tfhub.dev/tensorflow/bert_en_uncased_L-12_H-768_A-12/3"


class BERTClassifier(tf.keras.Model):
    """BERT-based classifier for sentiment analysis."""
    
    def __init__(self, num_classes: int, dropout_rate: float = 0.1):
        super(BERTClassifier, self).__init__()
        
        # Load BERT preprocessor and encoder
        self.preprocessor = hub.KerasLayer(BERT_PREPROCESSOR_URL)
        self.encoder = hub.KerasLayer(BERT_ENCODER_URL, trainable=True)  # Set to False for faster experiments
        
        # Classification head
        self.dropout = tf.keras.layers.Dropout(dropout_rate)
        self.dense = tf.keras.layers.Dense(128, activation='relu')
        self.classifier = tf.keras.layers.Dense(num_classes, activation='softmax')
    
    def call(self, inputs, training=None):
        # Preprocess input
        preprocessed = self.preprocessor(inputs)
        
        # Encode with BERT
        encoder_outputs = self.encoder(preprocessed)
        
        # Extract pooled output (CLS token representation)
        pooled_output = encoder_outputs['pooled_output']
        
        # Classification head
        x = self.dropout(pooled_output, training=training)
        x = self.dense(x)
        x = self.dropout(x, training=training)
        return self.classifier(x)


def load_and_preprocess_data(csv_path: str) -> Tuple[np.ndarray, np.ndarray, LabelEncoder]:
    """
    Load and preprocess labeled data for training.
    
    Args:
        csv_path: Path to labeled CSV file
    
    Returns:
        Tuple of (texts, labels, label_encoder)
    """
    print(f"Loading data from {csv_path}")
    df = pd.read_csv(csv_path)
    
    # Validate required columns
    required_cols = ['id', 'text', 'label']
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}")
    
    # Remove rows with missing data
    df = df.dropna(subset=['text', 'label'])
    
    print(f"Loaded {len(df)} samples")
    print(f"Label distribution:")
    print(df['label'].value_counts())
    
    # Encode labels
    label_encoder = LabelEncoder()
    labels_encoded = label_encoder.fit_transform(df['label'])
    
    return df['text'].values, labels_encoded, label_encoder


def create_model(num_classes: int, learning_rate: float = 2e-5) -> BERTClassifier:
    """
    Create and compile BERT classifier model.
    
    Args:
        num_classes: Number of output classes
        learning_rate: Learning rate for optimizer
    
    Returns:
        Compiled BERT classifier model
    """
    model = BERTClassifier(num_classes)
    
    # Compile model
    optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
    model.compile(
        optimizer=optimizer,
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )
    
    return model


def train_model(model: BERTClassifier, 
                texts: np.ndarray, 
                labels: np.ndarray,
                epochs: int = 3,
                batch_size: int = 8,
                validation_split: float = 0.2) -> tf.keras.callbacks.History:
    """
    Train the BERT classifier model.
    
    Args:
        model: BERT classifier model
        texts: Training texts
        labels: Training labels
        epochs: Number of training epochs
        batch_size: Batch size for training
        validation_split: Fraction of data to use for validation
    
    Returns:
        Training history
    """
    print(f"Training model for {epochs} epochs with batch size {batch_size}")
    
    # Split data
    X_train, X_val, y_train, y_val = train_test_split(
        texts, labels, test_size=validation_split, random_state=42, stratify=labels
    )
    
    print(f"Training samples: {len(X_train)}")
    print(f"Validation samples: {len(X_val)}")
    
    # Create datasets
    train_dataset = tf.data.Dataset.from_tensor_slices((X_train, y_train))
    val_dataset = tf.data.Dataset.from_tensor_slices((X_val, y_val))
    
    # Batch datasets
    train_dataset = train_dataset.batch(batch_size)
    val_dataset = val_dataset.batch(batch_size)
    
    # Callbacks
    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor='val_loss',
            patience=2,
            restore_best_weights=True
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor='val_loss',
            factor=0.5,
            patience=1,
            min_lr=1e-7
        )
    ]
    
    # Train model
    history = model.fit(
        train_dataset,
        validation_data=val_dataset,
        epochs=epochs,
        callbacks=callbacks,
        verbose=1
    )
    
    return history


def evaluate_model(model: BERTClassifier, 
                   texts: np.ndarray, 
                   labels: np.ndarray,
                   label_encoder: LabelEncoder) -> Dict[str, Any]:
    """
    Evaluate the trained model and generate metrics.
    
    Args:
        model: Trained BERT classifier
        texts: Test texts
        labels: Test labels
        label_encoder: Label encoder used for training
    
    Returns:
        Dictionary containing evaluation metrics
    """
    print("Evaluating model...")
    
    # Make predictions
    predictions = model.predict(texts)
    predicted_labels = np.argmax(predictions, axis=1)
    
    # Convert back to string labels
    predicted_labels_str = label_encoder.inverse_transform(predicted_labels)
    true_labels_str = label_encoder.inverse_transform(labels)
    
    # Generate classification report
    report = classification_report(
        true_labels_str, 
        predicted_labels_str, 
        output_dict=True
    )
    
    print("\nClassification Report:")
    print(classification_report(true_labels_str, predicted_labels_str))
    
    # Confusion matrix
    cm = confusion_matrix(true_labels_str, predicted_labels_str)
    
    # Plot confusion matrix
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                xticklabels=label_encoder.classes_,
                yticklabels=label_encoder.classes_)
    plt.title('Confusion Matrix')
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    plt.tight_layout()
    plt.savefig('confusion_matrix.png')
    plt.close()
    
    return {
        'classification_report': report,
        'confusion_matrix': cm.tolist(),
        'accuracy': report['accuracy']
    }


def save_model_and_metadata(model: BERTClassifier, 
                           label_encoder: LabelEncoder,
                           output_dir: str,
                           evaluation_metrics: Dict[str, Any]):
    """
    Save the trained model and associated metadata.
    
    Args:
        model: Trained BERT classifier
        label_encoder: Label encoder
        output_dir: Directory to save model and metadata
        evaluation_metrics: Model evaluation metrics
    """
    os.makedirs(output_dir, exist_ok=True)
    
    # Save model
    model_path = os.path.join(output_dir, 'model')
    model.save(model_path)
    print(f"Model saved to {model_path}")
    
    # Save label mapping
    label_map = {i: label for i, label in enumerate(label_encoder.classes_)}
    label_map_path = os.path.join(output_dir, 'label_map.json')
    with open(label_map_path, 'w') as f:
        json.dump(label_map, f, indent=2)
    print(f"Label map saved to {label_map_path}")
    
    # Save evaluation metrics
    metrics_path = os.path.join(output_dir, 'evaluation_metrics.json')
    with open(metrics_path, 'w') as f:
        json.dump(evaluation_metrics, f, indent=2)
    print(f"Evaluation metrics saved to {metrics_path}")
    
    # Save model info
    model_info = {
        'bert_preprocessor_url': BERT_PREPROCESSOR_URL,
        'bert_encoder_url': BERT_ENCODER_URL,
        'num_classes': len(label_encoder.classes_),
        'class_names': label_encoder.classes_.tolist(),
        'model_type': 'BERT Classifier'
    }
    
    info_path = os.path.join(output_dir, 'model_info.json')
    with open(info_path, 'w') as f:
        json.dump(model_info, f, indent=2)
    print(f"Model info saved to {info_path}")


def main():
    """Main training script."""
    parser = argparse.ArgumentParser(description="Train BERT model for sentiment analysis")
    
    parser.add_argument(
        "--csv",
        type=str,
        required=True,
        help="Path to labeled CSV file"
    )
    
    parser.add_argument(
        "--out",
        type=str,
        default="saved_model",
        help="Output directory for saved model"
    )
    
    parser.add_argument(
        "--epochs",
        type=int,
        default=3,
        help="Number of training epochs"
    )
    
    parser.add_argument(
        "--batch",
        type=int,
        default=8,
        help="Batch size for training"
    )
    
    parser.add_argument(
        "--learning-rate",
        type=float,
        default=2e-5,
        help="Learning rate for optimizer"
    )
    
    parser.add_argument(
        "--validation-split",
        type=float,
        default=0.2,
        help="Fraction of data to use for validation"
    )
    
    args = parser.parse_args()
    
    try:
        # Set random seeds for reproducibility
        tf.random.set_seed(42)
        np.random.seed(42)
        
        # Load and preprocess data
        texts, labels, label_encoder = load_and_preprocess_data(args.csv)
        
        # Create model
        num_classes = len(label_encoder.classes_)
        model = create_model(num_classes, args.learning_rate)
        
        print(f"Model created with {num_classes} classes: {label_encoder.classes_}")
        
        # Train model
        history = train_model(
            model, texts, labels,
            epochs=args.epochs,
            batch_size=args.batch,
            validation_split=args.validation_split
        )
        
        # Evaluate model
        evaluation_metrics = evaluate_model(model, texts, labels, label_encoder)
        
        # Save model and metadata
        save_model_and_metadata(model, label_encoder, args.out, evaluation_metrics)
        
        print(f"\nTraining completed successfully!")
        print(f"Final validation accuracy: {history.history['val_accuracy'][-1]:.4f}")
        
    except Exception as e:
        print(f"Error during training: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
