#!/usr/bin/env python3
"""
Input Handler for AI-Powered Draft Comment Analyzer

This module handles various input formats and creates standardized CSV files
for downstream processing by the sentiment analysis and summarization pipelines.
"""

import argparse
import csv
import os
import sys
from pathlib import Path
from typing import List, Dict, Any
import pandas as pd


def create_comments_csv(text: str = None, file_path: str = None, mode: str = "comment") -> str:
    """
    Create a standardized comments.csv file from various input sources.
    
    Args:
        text: Single comment or draft text
        file_path: Path to input file
        mode: Processing mode ('comment' or 'draft')
    
    Returns:
        Path to created CSV file
    """
    comments_data = []
    
    if text:
        if mode == "draft":
            # For draft mode, treat the entire text as one document
            comments_data.append({
                'id': 1,
                'text': text.strip(),
                'mode': 'draft'
            })
        else:
            # For comment mode, treat as single comment
            comments_data.append({
                'id': 1,
                'text': text.strip(),
                'mode': 'comment'
            })
    
    elif file_path:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Input file not found: {file_path}")
        
        with open(file_path, 'r', encoding='utf-8') as f:
            if mode == "draft":
                # Read entire file as one draft
                content = f.read().strip()
                comments_data.append({
                    'id': 1,
                    'text': content,
                    'mode': 'draft'
                })
            else:
                # Read line by line as separate comments
                for i, line in enumerate(f, 1):
                    line = line.strip()
                    if line:  # Skip empty lines
                        comments_data.append({
                            'id': i,
                            'text': line,
                            'mode': 'comment'
                        })
    
    else:
        raise ValueError("Either text or file_path must be provided")
    
    if not comments_data:
        raise ValueError("No valid input data found")
    
    # Create output CSV
    output_path = "comments.csv"
    df = pd.DataFrame(comments_data)
    df.to_csv(output_path, index=False)
    
    print(f"Created {output_path} with {len(comments_data)} entries")
    return output_path


def detect_draft_mode(text: str) -> bool:
    """
    Detect if text should be processed in draft mode based on length and structure.
    
    Args:
        text: Input text to analyze
    
    Returns:
        True if text should be processed as draft
    """
    if len(text) > 800:
        return True
    
    # Count sentences (rough estimate)
    sentence_count = text.count('.') + text.count('!') + text.count('?')
    if sentence_count > 5:
        return True
    
    return False


def main():
    """Main CLI interface for input handler."""
    parser = argparse.ArgumentParser(
        description="Process input text/files and create standardized CSV"
    )
    
    parser.add_argument(
        "--text",
        type=str,
        help="Single comment or draft text to analyze"
    )
    
    parser.add_argument(
        "--file",
        type=str,
        help="Path to input file (comments.txt or draft.txt)"
    )
    
    parser.add_argument(
        "--mode",
        type=str,
        choices=["comment", "draft"],
        default="comment",
        help="Processing mode: 'comment' for short comments, 'draft' for long documents"
    )
    
    parser.add_argument(
        "--auto-detect",
        action="store_true",
        help="Automatically detect draft mode based on text length"
    )
    
    args = parser.parse_args()
    
    if not args.text and not args.file:
        parser.error("Either --text or --file must be provided")
    
    try:
        # Auto-detect mode if requested
        mode = args.mode
        if args.auto_detect and args.text:
            if detect_draft_mode(args.text):
                mode = "draft"
                print("Auto-detected draft mode based on text length")
        
        # Create comments CSV
        csv_path = create_comments_csv(
            text=args.text,
            file_path=args.file,
            mode=mode
        )
        
        print(f"Successfully created {csv_path}")
        
        # Show preview
        df = pd.read_csv(csv_path)
        print(f"\nPreview of {csv_path}:")
        print(df.head())
        
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
