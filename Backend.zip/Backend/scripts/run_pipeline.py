#!/usr/bin/env python3
"""
Main Pipeline Orchestrator for AI-Powered Draft Comment Analyzer

This script orchestrates the entire analysis pipeline including input processing,
sentiment analysis, summarization, and word cloud generation.
"""

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import pandas as pd
import subprocess
import time


def run_command(command: List[str], description: str) -> bool:
    """
    Run a command and handle errors.
    
    Args:
        command: Command to run as list of strings
        description: Description of what the command does
    
    Returns:
        True if command succeeded, False otherwise
    """
    print(f"\n{'='*60}")
    print(f"Step: {description}")
    print(f"Command: {' '.join(command)}")
    print(f"{'='*60}")
    
    try:
        result = subprocess.run(command, check=True, capture_output=True, text=True)
        if result.stdout:
            print("Output:")
            print(result.stdout)
        return True
    except subprocess.CalledProcessError as e:
        print(f"Error: {e}")
        if e.stderr:
            print(f"Error output: {e.stderr}")
        return False


def create_input_csv(text: str = None, file_path: str = None, mode: str = "comment") -> str:
    """
    Create input CSV using input handler.
    
    Args:
        text: Single comment or draft text
        file_path: Path to input file
        mode: Processing mode
    
    Returns:
        Path to created CSV file
    """
    command = ["python", "scripts/input_handler.py"]
    
    if text:
        command.extend(["--text", text])
    elif file_path:
        command.extend(["--file", file_path])
    
    command.extend(["--mode", mode])
    
    success = run_command(command, "Creating input CSV")
    if not success:
        raise RuntimeError("Failed to create input CSV")
    
    return "comments.csv"


def run_sentiment_analysis(input_csv: str, 
                          model_dir: str = None,
                          sentence_level: bool = False) -> str:
    """
    Run sentiment analysis using BERT.
    
    Args:
        input_csv: Path to input CSV file
        model_dir: Path to custom trained model
        sentence_level: Whether to perform sentence-level analysis
    
    Returns:
        Path to results CSV file
    """
    command = [
        "python", "scripts/predict_bert_tf.py",
        "--input", input_csv,
        "--output", "tmp_with_sentiment.csv"
    ]
    
    if model_dir:
        command.extend(["--model-dir", model_dir])
    
    if sentence_level:
        command.append("--sentence-level")
    
    success = run_command(command, "Running sentiment analysis")
    if not success:
        raise RuntimeError("Failed to run sentiment analysis")
    
    return "tmp_with_sentiment.csv"


def run_summarization(input_csv: str,
                     sentence_level: bool = False,
                     max_chunk_chars: int = 1000,
                     max_summary_length: int = 150,
                     min_summary_length: int = 30,
                     device: str = "auto") -> str:
    """
    Run summarization using BART.
    
    Args:
        input_csv: Path to input CSV file
        sentence_level: Whether to process sentence-level results
        max_chunk_chars: Maximum characters per chunk
        max_summary_length: Maximum summary length
        min_summary_length: Minimum summary length
        device: Device to use for inference
    
    Returns:
        Path to final results CSV file
    """
    command = [
        "python", "scripts/summarize_hf.py",
        "--input", input_csv,
        "--output", "final_results.csv",
        "--max-chunk-chars", str(max_chunk_chars),
        "--max-summary-length", str(max_summary_length),
        "--min-summary-length", str(min_summary_length),
        "--device", device
    ]
    
    if sentence_level:
        command.append("--sentence-level")
    
    success = run_command(command, "Running summarization")
    if not success:
        raise RuntimeError("Failed to run summarization")
    
    return "final_results.csv"


def run_wordcloud_generation(input_csv: str,
                           sentence_level: bool = False,
                           by_sentiment: bool = False,
                           extra_stopwords: str = None) -> None:
    """
    Generate word clouds.
    
    Args:
        input_csv: Path to input CSV file
        sentence_level: Whether to process sentence-level results
        by_sentiment: Whether to generate sentiment-specific word clouds
        extra_stopwords: Path to additional stopwords file
    """
    command = [
        "python", "scripts/wordcloud.py",
        "--input", input_csv,
        "--output", "wordcloud.png"
    ]
    
    if sentence_level:
        command.append("--sentence-level")
    
    if by_sentiment:
        command.append("--by-sentiment")
    
    if extra_stopwords:
        command.extend(["--extra-stop", extra_stopwords])
    
    success = run_command(command, "Generating word clouds")
    if not success:
        print("Warning: Word cloud generation failed, continuing...")
    else:
        print("Word clouds generated successfully")


def create_draft_overview(sentence_results_csv: str) -> Dict[str, any]:
    """
    Create draft overview from sentence-level results.
    
    Args:
        sentence_results_csv: Path to sentence-level results CSV
    
    Returns:
        Dictionary with draft overview information
    """
    df = pd.read_csv(sentence_results_csv)
    
    if df.empty:
        return {
            'overall_sentiment': 'neutral',
            'confidence': 0.5,
            'total_sentences': 0,
            'positive_count': 0,
            'negative_count': 0,
            'neutral_count': 0
        }
    
    # Calculate aggregate sentiment
    sentiment_counts = df['sentiment'].value_counts()
    total_sentences = len(df)
    
    positive_count = sentiment_counts.get('positive', 0)
    negative_count = sentiment_counts.get('negative', 0)
    neutral_count = sentiment_counts.get('neutral', 0)
    
    # Determine overall sentiment (majority vote)
    if positive_count > negative_count and positive_count > neutral_count:
        overall_sentiment = 'positive'
    elif negative_count > positive_count and negative_count > neutral_count:
        overall_sentiment = 'negative'
    else:
        overall_sentiment = 'neutral'
    
    # Calculate confidence as average of sentence confidences
    confidence = df['sent_score'].mean()
    
    overview = {
        'overall_sentiment': overall_sentiment,
        'confidence': float(confidence),
        'total_sentences': total_sentences,
        'positive_count': int(positive_count),
        'negative_count': int(negative_count),
        'neutral_count': int(neutral_count)
    }
    
    # Save overview
    with open('draft_overview.json', 'w') as f:
        json.dump(overview, f, indent=2)
    
    return overview


def print_summary(mode: str, overview: Dict[str, any] = None) -> None:
    """
    Print human-friendly summary to CLI.
    
    Args:
        mode: Processing mode ('comment' or 'draft')
        overview: Draft overview information (for draft mode)
    """
    print(f"\n{'='*60}")
    print("ANALYSIS COMPLETE")
    print(f"{'='*60}")
    
    if mode == "draft" and overview:
        print(f"\nDRAFT ANALYSIS SUMMARY:")
        print(f"Overall Sentiment: {overview['overall_sentiment'].upper()}")
        print(f"Confidence: {overview['confidence']:.1%}")
        print(f"Total Sentences Analyzed: {overview['total_sentences']}")
        print(f"Sentiment Breakdown:")
        print(f"  • Positive: {overview['positive_count']} sentences")
        print(f"  • Negative: {overview['negative_count']} sentences")
        print(f"  • Neutral: {overview['neutral_count']} sentences")
        
        # Generate summary paragraph
        sentiment_desc = {
            'positive': 'generally positive',
            'negative': 'generally negative',
            'neutral': 'mixed or neutral'
        }
        
        summary_para = (
            f"The draft document shows {sentiment_desc[overview['overall_sentiment']]} sentiment "
            f"with {overview['confidence']:.1%} confidence. Out of {overview['total_sentences']} sentences analyzed, "
            f"{overview['positive_count']} were positive, {overview['negative_count']} were negative, "
            f"and {overview['neutral_count']} were neutral. "
        )
        
        if overview['overall_sentiment'] == 'positive':
            summary_para += "The overall tone suggests support or approval of the proposed measures."
        elif overview['overall_sentiment'] == 'negative':
            summary_para += "The overall tone suggests concerns or opposition to the proposed measures."
        else:
            summary_para += "The overall tone is balanced with mixed perspectives on the proposed measures."
        
        print(f"\nSUMMARY PARAGRAPH:")
        print(f"{summary_para}")
    
    else:
        print(f"\nCOMMENT ANALYSIS SUMMARY:")
        print("Sentiment analysis and summarization completed for all comments.")
        print("Check 'final_results.csv' for detailed results.")
    
    print(f"\nOUTPUT FILES GENERATED:")
    print(f"• final_results.csv - Detailed analysis results")
    if mode == "draft":
        print(f"• draft_overview.json - Overall document sentiment")
    print(f"• wordcloud.png - Keyword visualization")
    if mode == "draft":
        print(f"• wordcloud_positive.png - Positive sentiment keywords")
        print(f"• wordcloud_negative.png - Negative sentiment keywords")


def main():
    """Main pipeline orchestrator."""
    parser = argparse.ArgumentParser(
        description="AI-Powered Draft Comment Analyzer Pipeline"
    )
    
    parser.add_argument(
        "--text",
        type=str,
        help="Single comment or draft text to analyze"
    )
    
    parser.add_argument(
        "--file",
        type=str,
        help="Path to input file (comments.txt or draft.txt)"
    )
    
    parser.add_argument(
        "--mode",
        type=str,
        choices=["comment", "draft"],
        default="comment",
        help="Processing mode: 'comment' for short comments, 'draft' for long documents"
    )
    
    parser.add_argument(
        "--model-dir",
        type=str,
        help="Directory containing custom trained BERT model"
    )
    
    parser.add_argument(
        "--device",
        type=str,
        default="auto",
        choices=["auto", "cpu", "cuda"],
        help="Device to use for inference"
    )
    
    parser.add_argument(
        "--max-chunk-chars",
        type=int,
        default=1000,
        help="Maximum characters per chunk for summarization"
    )
    
    parser.add_argument(
        "--max-summary-length",
        type=int,
        default=150,
        help="Maximum summary length"
    )
    
    parser.add_argument(
        "--min-summary-length",
        type=int,
        default=30,
        help="Minimum summary length"
    )
    
    parser.add_argument(
        "--extra-stopwords",
        type=str,
        help="Path to additional stopwords file"
    )
    
    args = parser.parse_args()
    
    if not args.text and not args.file:
        parser.error("Either --text or --file must be provided")
    
    try:
        start_time = time.time()
        
        print("AI-Powered Draft Comment Analyzer")
        print("=" * 60)
        print(f"Mode: {args.mode}")
        print(f"Device: {args.device}")
        if args.model_dir:
            print(f"Custom Model: {args.model_dir}")
        print("=" * 60)
        
        # Step 1: Create input CSV
        input_csv = create_input_csv(
            text=args.text,
            file_path=args.file,
            mode=args.mode
        )
        
        # Step 2: Run sentiment analysis
        sentence_level = (args.mode == "draft")
        sentiment_csv = run_sentiment_analysis(
            input_csv,
            model_dir=args.model_dir,
            sentence_level=sentence_level
        )
        
        # Step 3: Run summarization
        final_csv = run_summarization(
            sentiment_csv,
            sentence_level=sentence_level,
            max_chunk_chars=args.max_chunk_chars,
            max_summary_length=args.max_summary_length,
            min_summary_length=args.min_summary_length,
            device=args.device
        )
        
        # Step 4: Generate word clouds
        run_wordcloud_generation(
            final_csv,
            sentence_level=sentence_level,
            by_sentiment=sentence_level,  # Generate sentiment-specific clouds for drafts
            extra_stopwords=args.extra_stopwords
        )
        
        # Step 5: Create draft overview (for draft mode)
        overview = None
        if args.mode == "draft":
            overview = create_draft_overview(final_csv)
        
        # Step 6: Print summary
        print_summary(args.mode, overview)
        
        end_time = time.time()
        print(f"\nTotal processing time: {end_time - start_time:.2f} seconds")
        
    except Exception as e:
        print(f"Pipeline failed: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
