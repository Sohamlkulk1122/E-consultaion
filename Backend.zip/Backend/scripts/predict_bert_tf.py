#!/usr/bin/env python3
"""
BERT Prediction Script for Sentiment Analysis

This script performs sentiment analysis using trained BERT models,
with support for both comment-level and sentence-level analysis.
"""

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import pandas as pd
import numpy as np
import tensorflow as tf
import tensorflow_hub as hub
try:
    import tensorflow_text as text  # noqa: F401
    _TF_TEXT_AVAILABLE = True
except Exception:
    _TF_TEXT_AVAILABLE = False
from transformers import pipeline as hf_pipeline
import nltk
from nltk.tokenize import sent_tokenize
import warnings
warnings.filterwarnings('ignore')


# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')


class BERTPredictor:
    """BERT-based sentiment predictor."""
    
    def __init__(self, model_dir: str = None):
        """
        Initialize BERT predictor.
        
        Args:
            model_dir: Directory containing trained model and metadata
        """
        self.model_dir = model_dir
        self.model = None
        self.label_map = None
        self.preprocessor = None
        self.encoder = None
        
        self.hf_sentiment = None
        if model_dir and os.path.exists(model_dir):
            self.load_custom_model(model_dir)
        else:
            self.load_pretrained_model()
    
    def load_custom_model(self, model_dir: str):
        """Load custom trained model."""
        print(f"Loading custom model from {model_dir}")
        
        # Load model
        model_path = os.path.join(model_dir, 'model')
        if os.path.exists(model_path):
            self.model = tf.keras.models.load_model(model_path)
            print("Custom model loaded successfully")
        else:
            raise FileNotFoundError(f"Model not found at {model_path}")
        
        # Load label map
        label_map_path = os.path.join(model_dir, 'label_map.json')
        if os.path.exists(label_map_path):
            with open(label_map_path, 'r', encoding='utf-8') as f:
                self.label_map = json.load(f)
            print(f"Label map loaded: {self.label_map}")
        else:
            print("Warning: No label map found, using numeric labels")
    
    def load_pretrained_model(self):
        """Load a default sentiment model.
        Prefer TF Hub pipeline if tensorflow_text is available, otherwise use HF transformers.
        """
        if _TF_TEXT_AVAILABLE:
            print("Loading pretrained BERT model via TF Hub")
            preprocessor_url = "https://tfhub.dev/tensorflow/bert_en_uncased_preprocess/3"
            encoder_url = "https://tfhub.dev/tensorflow/bert_en_uncased_L-12_H-768_A-12/3"
            self.preprocessor = hub.KerasLayer(preprocessor_url)
            self.encoder = hub.KerasLayer(encoder_url, trainable=False)
            self.model = tf.keras.Sequential([
                tf.keras.layers.Input(shape=(), dtype=tf.string),
                self.preprocessor,
                self.encoder,
                tf.keras.layers.Dense(3, activation='softmax')
            ])
            self.label_map = {0: 'negative', 1: 'neutral', 2: 'positive'}
            print("TF Hub model ready")
        else:
            print("tensorflow_text not available; using Hugging Face sentiment model")
            # Robust 3-class model
            self.hf_sentiment = hf_pipeline(
                "sentiment-analysis",
                model="cardiffnlp/twitter-roberta-base-sentiment",
                tokenizer="cardiffnlp/twitter-roberta-base-sentiment"
            )
            self.label_map = {0: 'negative', 1: 'neutral', 2: 'positive'}
            print("HF transformers model ready")
    
    def predict_sentiment(self, texts: List[str]) -> Tuple[np.ndarray, np.ndarray]:
        """
        Predict sentiment for a list of texts.
        
        Args:
            texts: List of input texts
        
        Returns:
            Tuple of (predicted_labels, confidence_scores)
        """
        if not texts:
            return np.array([]), np.array([])
        
        if self.hf_sentiment is not None:
            # Hugging Face pipelines expect str or list[str]
            if isinstance(texts, np.ndarray):
                texts = texts.tolist()
            elif not isinstance(texts, list):
                texts = list(texts)
            # Ensure plain Python strs
            texts = ["" if t is None else (t if isinstance(t, str) else str(t)) for t in texts]
            labels = []
            scores = []
            # Call pipeline per-text to avoid type edge cases in batch mode
            for t in texts:
                out_list = self.hf_sentiment(t, truncation=True)
                out = out_list[0] if isinstance(out_list, list) else out_list
                label = str(out.get('label', '')).lower()
                score = float(out.get('score', 0.0))
                if 'neg' in label or label.endswith('_0'):
                    labels.append(0)
                elif 'pos' in label or label.endswith('_2'):
                    labels.append(2)
                else:
                    labels.append(1)
                scores.append(score)
            return np.array(labels), np.array(scores)
        else:
            predictions = self.model.predict(texts, verbose=0)
            predicted_labels = np.argmax(predictions, axis=1)
            confidence_scores = np.max(predictions, axis=1)
            return predicted_labels, confidence_scores
    
    def get_sentiment_label(self, label_id: int) -> str:
        """Convert numeric label to string label."""
        if not self.label_map:
            return f"class_{label_id}"
        # Accept both str and int keys
        if isinstance(self.label_map, dict):
            if label_id in self.label_map:
                return self.label_map[label_id]
            if str(label_id) in self.label_map:
                return self.label_map[str(label_id)]
        return f"class_{label_id}"


def tokenize_sentences(text: str) -> List[str]:
    """
    Tokenize text into sentences.
    
    Args:
        text: Input text
    
    Returns:
        List of sentences
    """
    sentences = sent_tokenize(text)
    # Filter out very short sentences (likely artifacts)
    sentences = [s.strip() for s in sentences if len(s.strip()) > 10]
    return sentences


def analyze_comments(input_csv: str, 
                    predictor: BERTPredictor,
                    sentence_level: bool = False) -> pd.DataFrame:
    """
    Analyze comments for sentiment.
    
    Args:
        input_csv: Path to input CSV file
        predictor: BERT predictor instance
        sentence_level: Whether to perform sentence-level analysis
    
    Returns:
        DataFrame with sentiment analysis results
    """
    print(f"Loading comments from {input_csv}")
    df = pd.read_csv(input_csv)
    
    if sentence_level:
        return analyze_sentence_level(df, predictor)
    else:
        return analyze_comment_level(df, predictor)


def analyze_comment_level(df: pd.DataFrame, predictor: BERTPredictor) -> pd.DataFrame:
    """Analyze sentiment at comment level."""
    print("Performing comment-level sentiment analysis")
    
    results = []
    
    for idx, row in df.iterrows():
        text = str(row['text'])
        
        # Predict sentiment
        labels, scores = predictor.predict_sentiment([text])
        
        # Get results
        label_id = labels[0]
        score = scores[0]
        sentiment = predictor.get_sentiment_label(label_id)
        
        results.append({
            'id': row['id'],
            'text': text,
            'sent_label_id': int(label_id),
            'sent_score': float(score),
            'sentiment': sentiment
        })
    
    return pd.DataFrame(results)


def analyze_sentence_level(df: pd.DataFrame, predictor: BERTPredictor) -> pd.DataFrame:
    """Analyze sentiment at sentence level for draft documents."""
    print("Performing sentence-level sentiment analysis")
    
    results = []
    
    for idx, row in df.iterrows():
        text = str(row['text'])
        
        # Tokenize into sentences
        sentences = tokenize_sentences(text)
        
        if not sentences:
            # Fallback to treating entire text as one sentence
            sentences = [text]
        
        print(f"Document {row['id']}: {len(sentences)} sentences")
        
        # Predict sentiment for each sentence
        labels, scores = predictor.predict_sentiment(sentences)
        
        # Add results for each sentence
        for sent_idx, (sentence, label_id, score) in enumerate(zip(sentences, labels, scores)):
            sentiment = predictor.get_sentiment_label(label_id)
            
            results.append({
                'id': row['id'],
                'sentence_id': sent_idx + 1,
                'text': text,
                'sentence_text': sentence,
                'sent_label_id': int(label_id),
                'sent_score': float(score),
                'sentiment': sentiment
            })
    
    return pd.DataFrame(results)


def calculate_aggregate_sentiment(sentence_results: pd.DataFrame) -> Dict[str, any]:
    """
    Calculate aggregate sentiment for a document from sentence-level results.
    
    Args:
        sentence_results: DataFrame with sentence-level sentiment results
    
    Returns:
        Dictionary with aggregate sentiment information
    """
    if sentence_results.empty:
        return {
            'overall_sentiment': 'neutral',
            'confidence': 0.5,
            'total_sentences': 0,
            'positive_count': 0,
            'negative_count': 0,
            'neutral_count': 0
        }
    
    # Count sentiments
    sentiment_counts = sentence_results['sentiment'].value_counts()
    total_sentences = len(sentence_results)
    
    positive_count = sentiment_counts.get('positive', 0)
    negative_count = sentiment_counts.get('negative', 0)
    neutral_count = sentiment_counts.get('neutral', 0)
    
    # Determine overall sentiment (majority vote)
    if positive_count > negative_count and positive_count > neutral_count:
        overall_sentiment = 'positive'
    elif negative_count > positive_count and negative_count > neutral_count:
        overall_sentiment = 'negative'
    else:
        overall_sentiment = 'neutral'
    
    # Calculate confidence as average of sentence confidences
    confidence = sentence_results['sent_score'].mean()
    
    return {
        'overall_sentiment': overall_sentiment,
        'confidence': float(confidence),
        'total_sentences': total_sentences,
        'positive_count': int(positive_count),
        'negative_count': int(negative_count),
        'neutral_count': int(neutral_count)
    }


def main():
    """Main prediction script."""
    parser = argparse.ArgumentParser(description="Predict sentiment using BERT")
    
    parser.add_argument(
        "--input",
        type=str,
        required=True,
        help="Input CSV file path"
    )
    
    parser.add_argument(
        "--model-dir",
        type=str,
        help="Directory containing trained model"
    )
    
    parser.add_argument(
        "--sentence-level",
        action="store_true",
        help="Perform sentence-level analysis for draft documents"
    )
    
    parser.add_argument(
        "--output",
        type=str,
        default="tmp_with_sentiment.csv",
        help="Output CSV file path"
    )
    
    args = parser.parse_args()
    
    try:
        # Initialize predictor
        predictor = BERTPredictor(args.model_dir)
        
        # Analyze comments
        results_df = analyze_comments(
            args.input, 
            predictor, 
            sentence_level=args.sentence_level
        )
        
        # Save results
        results_df.to_csv(args.output, index=False)
        print(f"Results saved to {args.output}")
        
        # If sentence-level analysis, also create aggregate summary
        if args.sentence_level and not results_df.empty:
            # Group by document ID and calculate aggregate sentiment
            doc_summaries = []
            
            for doc_id in results_df['id'].unique():
                doc_sentences = results_df[results_df['id'] == doc_id]
                aggregate = calculate_aggregate_sentiment(doc_sentences)
                aggregate['document_id'] = doc_id
                doc_summaries.append(aggregate)
            
            # Save aggregate results
            aggregate_df = pd.DataFrame(doc_summaries)
            aggregate_output = args.output.replace('.csv', '_aggregate.csv')
            aggregate_df.to_csv(aggregate_output, index=False)
            print(f"Aggregate results saved to {aggregate_output}")
            
            # Print summary
            for summary in doc_summaries:
                print(f"\nDocument {summary['document_id']} Summary:")
                print(f"  Overall Sentiment: {summary['overall_sentiment']}")
                print(f"  Confidence: {summary['confidence']:.3f}")
                print(f"  Total Sentences: {summary['total_sentences']}")
                print(f"  Positive: {summary['positive_count']}, "
                      f"Negative: {summary['negative_count']}, "
                      f"Neutral: {summary['neutral_count']}")
        
        print(f"\nSentiment analysis completed successfully!")
        
    except Exception as e:
        print(f"Error during prediction: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
