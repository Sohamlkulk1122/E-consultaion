#!/usr/bin/env python3
"""
BART Summarization Script

This script performs abstractive summarization using Hugging Face BART model,
with support for chunking long documents and re-summarization.
"""

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import pandas as pd
import torch
from transformers import pipeline, AutoTokenizer, AutoModelForSeq2SeqLM
import nltk
from nltk.tokenize import sent_tokenize
import warnings
warnings.filterwarnings('ignore')


# Download required NLTK data
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')


class BARTSummarizer:
    """BART-based text summarizer with chunking support."""
    
    def __init__(self, 
                 model_name: str = "facebook/bart-large-cnn",
                 device: str = "auto",
                 max_length: int = 150,
                 min_length: int = 30):
        """
        Initialize BART summarizer.
        
        Args:
            model_name: Hugging Face model name
            device: Device to use ('cpu', 'cuda', or 'auto')
            max_length: Maximum summary length
            min_length: Minimum summary length
        """
        self.model_name = model_name
        self.max_length = max_length
        self.min_length = min_length
        
        # Determine device
        if device == "auto":
            self.device = 0 if torch.cuda.is_available() else -1
        elif device == "cuda":
            self.device = 0 if torch.cuda.is_available() else -1
        else:
            self.device = -1
        
        print(f"Initializing BART summarizer on device: {self.device}")
        
        # Initialize summarization pipeline
        self.summarizer = pipeline(
            "summarization",
            model=model_name,
            device=self.device,
            max_length=max_length,
            min_length=min_length
        )
        
        print(f"BART summarizer loaded successfully")
    
    def chunk_text(self, text: str, max_chunk_chars: int = 1000) -> List[str]:
        """
        Split text into chunks suitable for BART processing.
        
        Args:
            text: Input text to chunk
            max_chunk_chars: Maximum characters per chunk
        
        Returns:
            List of text chunks
        """
        if len(text) <= max_chunk_chars:
            return [text]
        
        # Split by sentences first
        sentences = sent_tokenize(text)
        
        chunks = []
        current_chunk = ""
        
        for sentence in sentences:
            # If adding this sentence would exceed the limit, start a new chunk
            if len(current_chunk) + len(sentence) > max_chunk_chars and current_chunk:
                chunks.append(current_chunk.strip())
                current_chunk = sentence
            else:
                current_chunk += " " + sentence if current_chunk else sentence
        
        # Add the last chunk
        if current_chunk.strip():
            chunks.append(current_chunk.strip())
        
        return chunks
    
    def summarize_text(self, text: str, max_chunk_chars: int = 1000) -> str:
        """
        Summarize text using BART with chunking for long documents.
        
        Args:
            text: Input text to summarize
            max_chunk_chars: Maximum characters per chunk
        
        Returns:
            Summarized text
        """
        if not text.strip():
            return ""
        
        # Chunk the text if it's too long
        chunks = self.chunk_text(text, max_chunk_chars)
        
        if len(chunks) == 1:
            # Single chunk - summarize directly
            try:
                result = self.summarizer(chunks[0])
                return result[0]['summary_text']
            except Exception as e:
                print(f"Error summarizing single chunk: {e}")
                return chunks[0][:self.max_length] + "..."
        
        else:
            # Multiple chunks - summarize each and then re-summarize
            print(f"Summarizing {len(chunks)} chunks")
            
            chunk_summaries = []
            for i, chunk in enumerate(chunks):
                try:
                    result = self.summarizer(chunk)
                    summary = result[0]['summary_text']
                    chunk_summaries.append(summary)
                    print(f"Chunk {i+1}/{len(chunks)} summarized")
                except Exception as e:
                    print(f"Error summarizing chunk {i+1}: {e}")
                    # Fallback to truncation
                    chunk_summaries.append(chunk[:self.max_length] + "...")
            
            # Combine chunk summaries
            combined_summary = " ".join(chunk_summaries)
            
            # Re-summarize if the combined summary is still long
            if len(combined_summary) > max_chunk_chars:
                try:
                    final_result = self.summarizer(combined_summary)
                    return final_result[0]['summary_text']
                except Exception as e:
                    print(f"Error re-summarizing: {e}")
                    return combined_summary[:self.max_length] + "..."
            else:
                return combined_summary
    
    def summarize_batch(self, texts: List[str], max_chunk_chars: int = 1000) -> List[str]:
        """
        Summarize a batch of texts.
        
        Args:
            texts: List of texts to summarize
            max_chunk_chars: Maximum characters per chunk
        
        Returns:
            List of summaries
        """
        summaries = []
        
        for i, text in enumerate(texts):
            print(f"Summarizing text {i+1}/{len(texts)}")
            summary = self.summarize_text(text, max_chunk_chars)
            summaries.append(summary)
        
        return summaries


def process_comments_with_summaries(input_csv: str, 
                                  summarizer: BARTSummarizer,
                                  max_chunk_chars: int = 1000) -> pd.DataFrame:
    """
    Process comments and add summaries.
    
    Args:
        input_csv: Path to input CSV file
        summarizer: BART summarizer instance
        max_chunk_chars: Maximum characters per chunk
    
    Returns:
        DataFrame with added summary column
    """
    print(f"Loading comments from {input_csv}")
    df = pd.read_csv(input_csv)
    
    # Add summary column
    summaries = summarizer.summarize_batch(df['text'].tolist(), max_chunk_chars)
    df['summary'] = summaries
    
    return df


def process_sentence_level_with_summaries(input_csv: str,
                                         summarizer: BARTSummarizer,
                                         max_chunk_chars: int = 1000) -> Tuple[pd.DataFrame, Dict[str, str]]:
    """
    Process sentence-level results and add document-level summaries.
    
    Args:
        input_csv: Path to input CSV file with sentence-level results
        summarizer: BART summarizer instance
        max_chunk_chars: Maximum characters per chunk
    
    Returns:
        Tuple of (DataFrame with summaries, document summaries dict)
    """
    print(f"Loading sentence-level results from {input_csv}")
    df = pd.read_csv(input_csv)
    
    if df.empty:
        return df, {}
    
    # Group by document ID
    document_summaries = {}
    
    for doc_id in df['id'].unique():
        doc_sentences = df[df['id'] == doc_id]
        
        # Get original text (should be the same for all sentences in a document)
        original_text = doc_sentences.iloc[0]['text']
        
        print(f"Summarizing document {doc_id}")
        summary = summarizer.summarize_text(original_text, max_chunk_chars)
        document_summaries[str(doc_id)] = summary
    
    # Add document summary to each row
    df['document_summary'] = df['id'].astype(str).map(document_summaries)
    
    return df, document_summaries


def main():
    """Main summarization script."""
    parser = argparse.ArgumentParser(description="Summarize text using BART")
    
    parser.add_argument(
        "--input",
        type=str,
        required=True,
        help="Input CSV file path"
    )
    
    parser.add_argument(
        "--output",
        type=str,
        default="final_results.csv",
        help="Output CSV file path"
    )
    
    parser.add_argument(
        "--model",
        type=str,
        default="facebook/bart-large-cnn",
        help="Hugging Face model name"
    )
    
    parser.add_argument(
        "--device",
        type=str,
        default="auto",
        choices=["auto", "cpu", "cuda"],
        help="Device to use for inference"
    )
    
    parser.add_argument(
        "--max-chunk-chars",
        type=int,
        default=1000,
        help="Maximum characters per chunk"
    )
    
    parser.add_argument(
        "--max-summary-length",
        type=int,
        default=150,
        help="Maximum summary length"
    )
    
    parser.add_argument(
        "--min-summary-length",
        type=int,
        default=30,
        help="Minimum summary length"
    )
    
    parser.add_argument(
        "--sentence-level",
        action="store_true",
        help="Process sentence-level results (draft mode)"
    )
    
    args = parser.parse_args()
    
    try:
        # Initialize summarizer
        summarizer = BARTSummarizer(
            model_name=args.model,
            device=args.device,
            max_length=args.max_summary_length,
            min_length=args.min_summary_length
        )
        
        if args.sentence_level:
            # Process sentence-level results
            results_df, doc_summaries = process_sentence_level_with_summaries(
                args.input, summarizer, args.max_chunk_chars
            )
            
            # Save results
            results_df.to_csv(args.output, index=False)
            print(f"Results saved to {args.output}")
            
            # Save document summaries
            summaries_output = args.output.replace('.csv', '_summaries.json')
            with open(summaries_output, 'w') as f:
                json.dump(doc_summaries, f, indent=2)
            print(f"Document summaries saved to {summaries_output}")
            
        else:
            # Process comment-level results
            results_df = process_comments_with_summaries(
                args.input, summarizer, args.max_chunk_chars
            )
            
            # Save results
            results_df.to_csv(args.output, index=False)
            print(f"Results saved to {args.output}")
        
        print(f"\nSummarization completed successfully!")
        
        # Show preview
        print(f"\nPreview of {args.output}:")
        print(results_df.head())
        
    except Exception as e:
        print(f"Error during summarization: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
